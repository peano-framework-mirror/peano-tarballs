#include "tarch/plotter/griddata/blockstructured/PatchWriter.h"


tarch::multicore::BooleanSemaphore tarch::plotter::griddata::blockstructured::PatchWriter::SinglePatchWriter::_semaphore;


tarch::plotter::griddata::blockstructured::PatchWriter::~PatchWriter() {
}
