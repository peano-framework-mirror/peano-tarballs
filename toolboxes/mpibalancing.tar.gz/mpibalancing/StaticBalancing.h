// This file is part of the Peano project. For conditions of distribution and
// use, please see the copyright notice at www.peano-framework.org
#ifndef _MPI_BALANCING_STATIC_BALANCING_H_
#define _MPI_BALANCING_STATIC_BALANCING_H_

#include "peano/parallel/loadbalancing/OracleForOnePhase.h"
#include "tarch/logging/Log.h"


#include <map>
#include <set>


namespace mpibalancing {
  class StaticBalancing;
}


/**
 * Static Balancing
 *
 * This balancing identifies the critical path locally, i.e. if the oracle is
 * told by its master that it shall fork at least once, it identifies its worker
 * with the biggest load and makes this one fork as well. Please note that the
 * critical path can be multiple ranks that are forked at the same time.
 *
 * !!! getCommandForWorker()
 *
 * getCommandForWorker() here is pretty simple and evaluates basically
 * _forksToConduct and _criticalWorker identifying whether the worker shall
 * fork or not. There are few special cases besides this:
 *
 * - If the oracle is running on the global master and the weight table holds
 *   only one entry (i.e. the weight of the local rank), this is the very
 *   root of the logic mpi tree and calls its worker to fork all of its nodes,
 *   i.e. we make rank 0 and rank 1 fork all their children. This way, we can
 *   evaluate on rank 1 really which subtree is the biggest one. If we'd fork
 *   all subtrees besides one on rank 1, this would not be possible that easy,
 *   as it is complicated to identify the real local workload throughout a
 *   traversal.
 * - If the oracle is asked for the command for a worker who couldn't erase
 *   before due to the domain decomposition and if joins are globally allowed,
 *   we join this one to facilitate that erases pass through and the global
 *   grid becomes smaller.
 *
 *
 * !!! receivedStartCommand()
 *
 * This operation is the critical path analysis. If its command from above is
 * unequal to fork, there's no analysis to be done, i.e. we evaluate the
 * critical path recursively which works as we are working in a tree
 * environment.
 *
 * If we shall fork, we first identify the biggest and the smallest local
 * workload. For the latter, we have to be careful as the local workload is
 * by default set to 1. Now, if the worker (the one directly below the global
 * master, e.g.) forks all of its children, this local workload remains 1,
 * which is an unrealistic value. So we exclude that one explicitly from our
 * search.
 *
 * Now that we have the minimum and maximum workload as well as the cricial
 * worker, i.e. the one having the biggest workload (which might be the
 * local rank as well), we determine the number of forks to conduct. The
 * formula for this endeavour is as follows: We assume (at the beginning)
 * that k forks reduce the worker's workload by
 *
 * @f$ w \gets w \cdot \frac{3^d-k}{3^d} @f$
 *
 * This assumption is based upon a regular grid. If the cricial weight shall
 * equal the smallest weight, we obtain
 *
 * @f$ w_{critical} \cdot \frac{3^d-k}{3^d} = w_{minimum} @f$
 * @f$ k = 3^d \left( 1-\frac{w_{minimum}}{w_{critical}} \right) @f$
 *
 * Finally, we ensure that the forks are bounded by @f$ 3^d-1 @f$ or reset
 * the critical worker if no forks are to be done.
 *
 * !!! Local Minima
 *
 * If we have p ranks, it can happen that the oracle achieves perfect balancing with
 * @f$ \hat p < p @f$ ranks already. If we have 50 ranks, 10 in 2d already are perfectly
 * balanced though then 40 ranks remain idle. In this case, the critical path analysis
 * runs into a local minimum. We identify such a minimum or we assume that we are in
 * such a minimum, if the critical weight differs from the minimum weight by less then
 * LocalMinimumThreshold percent.
 *
 * If we identify a local minimum, we set the numbers to fork manually to
 * @f$3^d-1 @f$ and label alll workers as critical.
 * From now on, the formula from above that dermines fork numbers doesn't work anymore.
 * We cannot assume that any worker still has @f$ 3^d @f$ children to fork. As a
 * consequence, we scale the whole fork numbers down by a factor of 1.1. This factor is
 * empirically. Please note that the effective scaling is typically
 * @f$ 1.1 ^4 \approx 1.45 @f$ as the local minimum analysis will trigger several times
 * until the grid is balanced and can rebalance again. So whenever we encounter a local
 * minimum, we are more carefully with rebalancing.
 *
 * @image html StaticBalancing.png
 * @author Tobias Weinzierl
 */
class mpibalancing::StaticBalancing: public peano::parallel::loadbalancing::OracleForOnePhase {
  public:
    /**
     * Constructor
     *
     * @param joinsAllowed The static balancing does, as the name suggests, not
     *                     join any partitions throughout the computation. Only
     *                     if grid erases do not pass through due to the domain
     *                     decomposition, it supports joins if this flag is set
     *                     true.
     */
    StaticBalancing(bool joinsAllowed);

    virtual ~StaticBalancing();

    /**
     * Analyse which workers are to be forked next.
     *
     * This operation is described in detail within the class documentation as
     * it realises the actual algorithm.
     */
    virtual void receivedStartCommand(const int commandFromMaster );

    virtual int getCommandForWorker( int workerRank, bool forkIsAllowed, bool joinIsAllowed );

    virtual void receivedTerminateCommand(
      int     workerRank,
      double  workerNumberOfInnerVertices,
      double  workerNumberOfBoundaryVertices,
      double  workerNumberOfOuterVertices,
      double  workerNumberOfInnerCells,
      double  workerNumberOfOuterCells,
      int     workerMaxLevel,
      double  workerLocalWorkload,
      double  workerTotalWorkload,
      double  workerMaxWorkload,
      double  workerMinWorkload,
      int     currentLevel,
      double  parentCellLocalWorkload,
      const tarch::la::Vector<DIMENSIONS,double>& boundingBoxOffset,
      const tarch::la::Vector<DIMENSIONS,double>& boundingBoxSize,
      bool    workerCouldNotEraseDueToDecomposition
    );

    virtual void plotStatistics();

    virtual peano::parallel::loadbalancing::OracleForOnePhase* createNewOracle(int adapterNumber) const;

    virtual void forkFailed();
 
    virtual int getCoarsestRegularInnerAndOuterGridLevel() const;

    virtual void couldNotEraseDueToDecomposition();

  private:
    /**
     * Logging device
     */
    static tarch::logging::Log  _log;

    /**
     * If a fork failed, all the oracles should stop to ask for further forks.
     * Wouldn't make sense and just slow down the application.
     */
    static bool                 _forkHasFailed;

    /**
     * Global flag set at construction time.
     */
    const bool                  _joinsAllowed;
    
    /**
     * Holds for each worker its local weight.
     */
    std::map<int,double>        _weightMap;

    /**
     * Bookkeeps for each worker whether this one couldn't erase due to the
     * domain decomposition.
     */
    std::map<int,bool>          _workerCouldNotEraseDueToDecomposition;

    /**
     * Set of critical workers
     *
     * This set might be empty, but it can also contain multiple critical
     * workers. All critical workers will receive fork commands if Peano
     * asks for a load balancing command next. What type of fork command
     * they receive is held in _forksToConduct.
     */
    std::set<int>               _criticalWorker;

    /**
     * How many forks shall any critical worker conduct.
     */
    int                         _forksToConduct;

    /**
     * Constraint on _forksToConduct
     *
     * This field typically is set to 3^d at the beginning. Whenever we run
     * into a local minimum, i.e. locally we see that everything is
     * well-balanced, we tell all the children to fork greedy, i.e. 3^d-1
     * times. In this case, _maxForks is not an upper constraint for
     * _forksToConduct. However, we afterward reduce _maxForks and thus
     * throttle the future splitting.
     */
    double                      _maxForks;

    /**
     * Finest administrative level
     *
     * Up to a certain level, this balancer tries to fork 3^d times. It tries
     * to make itself a pure administrative rank. The level is set such that
     * the next level cannot exploit all remaining mpi rank. This attribute is
     * set once in the constructor. Afterwards, the oracle analyses the
     * _coarsestLevelForked and uses this one to come up with a decision.
     */
    int                         _finestAdministrativeLevel;

    /**
     * @see _finestAdministrativeLevel
     */
    bool                        _makeChildrenAdministrativeRanks;
};



#endif
