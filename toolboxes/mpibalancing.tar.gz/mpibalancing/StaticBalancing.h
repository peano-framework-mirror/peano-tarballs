// This file is part of the Peano project. For conditions of distribution and
// use, please see the copyright notice at www.peano-framework.org
#ifndef _MPI_BALANCING_STATIC_BALANCING_H_
#define _MPI_BALANCING_STATIC_BALANCING_H_

#include "peano/parallel/loadbalancing/OracleForOnePhase.h"
#include "tarch/logging/Log.h"


#include <map>


namespace mpibalancing {
  class StaticBalancing;
}


/**
 * Static Balancing
 *
 * @author Tobias Weinzierl
 */
class mpibalancing::StaticBalancing: public peano::parallel::loadbalancing::OracleForOnePhase {
  public:
    /**
     * Constructor
     *
     * @param joinsAllowed The static balancing does, as the name suggests, not
     *                     join any partitions throughout the computation. Only
     *                     if grid erases do not pass through due to the domain
     *                     decomposition, it supports joins if this flag is set
     *                     true.
     */
    StaticBalancing(bool joinsAllowed);

    virtual ~StaticBalancing();

    virtual void receivedStartCommand(const int commandFromMaster );

    virtual int getCommandForWorker( int workerRank, bool forkIsAllowed, bool joinIsAllowed );

    virtual void receivedTerminateCommand(
      int     workerRank,
      double  waitedTime,
      double  workerNumberOfInnerVertices,
      double  workerNumberOfBoundaryVertices,
      double  workerNumberOfOuterVertices,
      double  workerNumberOfInnerCells,
      double  workerNumberOfOuterCells,
      int     workerMaxLevel,
      double  workerLocalWorkload,
      double  workerTotalWorkload,
      int     currentLevel,
      double  parentCellLocalWorkload,
      double  parentCellTotalWorkload,
      const tarch::la::Vector<DIMENSIONS,double>& boundingBoxOffset,
      const tarch::la::Vector<DIMENSIONS,double>& boundingBoxSize,
      bool    workerCouldNotEraseDueToDecomposition
    );

    virtual void plotStatistics();

    virtual peano::parallel::loadbalancing::OracleForOnePhase* createNewOracle(int adapterNumber) const;

    virtual void forkFailed();
 
    virtual int getCoarsestRegularInnerAndOuterGridLevel() const;

    virtual void couldNotEraseDueToDecomposition();

  private:
    /**
     * Logging device
     */
    static tarch::logging::Log  _log;

    /**
     * If a fork failed, all the oracles should stop to ask for further forks.
     * Wouldn't make sense and just slow down the application.
     */
    static bool                 _forkHasFailed;

    /**
     * Global flag set at construction time.
     */
    const bool                  _joinsAllowed;
    
    int                         _commandFromMaster;

    std::map<int,double>        _weightMap;
    std::map<int,bool>          _workerCouldNotEraseDueToDecomposition;

    int                         _criticalWorker;
    int                         _forksToConduct;
};



#endif // _ORACLE_FOR_ONE_PHASE_BINARY_PARTITIONING_H_
