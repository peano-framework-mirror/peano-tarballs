#include "mpibalancing/StaticBalancing.h"

#include "tarch/Assertions.h"
#include "tarch/la/ScalarOperations.h"
#include "tarch/parallel/Node.h"
#include "tarch/parallel/NodePool.h"
#include "peano/parallel/loadbalancing/Oracle.h"


tarch::logging::Log mpibalancing::StaticBalancing::_log( "mpibalancing::StaticBalancing" );


bool mpibalancing::StaticBalancing::_forkHasFailed = false;


mpibalancing::StaticBalancing::StaticBalancing(bool joinsAllowed):
  _joinsAllowed(joinsAllowed),
  _criticalWorker(),
  _forksToConduct(0),
  _maxForks(THREE_POWER_D),
  _finestAdministrativeLevel(1),
  _makeChildrenAdministrativeRanks( false ) {
  _weightMap.insert( std::pair<int,double>(tarch::parallel::Node::getInstance().getRank(), 1.0) );
  _workerCouldNotEraseDueToDecomposition.insert( std::pair<int,bool>(tarch::parallel::Node::getInstance().getRank(), false) );

  int regularCellsPerLevel = tarch::la::aPowI(DIMENSIONS*_finestAdministrativeLevel,3);
  while ( regularCellsPerLevel < tarch::parallel::Node::getInstance().getNumberOfNodes() ) {
    _finestAdministrativeLevel++;
    regularCellsPerLevel += tarch::la::aPowI(DIMENSIONS*_finestAdministrativeLevel,3);
  }
  _finestAdministrativeLevel--;
}


mpibalancing::StaticBalancing::~StaticBalancing() {
}


void mpibalancing::StaticBalancing::receivedStartCommand(const int commandFromMaster ) {
  logTraceInWith1Argument("receivedStartCommand(LoadBalancingFlag)", peano::parallel::loadbalancing::convertLoadBalancingFlagToString(commandFromMaster));

  /**
   * We consider the CritialPathThreshold upper percent of the workers to be
   * critical.
   */
  const double CritialPathThreshold = 0.1;

  /**
   * If minimum and critical weight differ by less than LocalMinimumThreshold
   * percent, we assume that we've ran into a local minimum.
   */
  const double LocalMinimumThreshold = 0.1;

  _criticalWorker.clear();

  if (
      commandFromMaster>=peano::parallel::loadbalancing::ForkOnce ||
      commandFromMaster==peano::parallel::loadbalancing::Continue
  ) {
    double maximumWeight = std::numeric_limits<double>::min();
    double minimumWeight  = std::numeric_limits<double>::max();
    for ( std::map<int,double>::const_iterator p=_weightMap.begin(); p!=_weightMap.end(); p++ ) {
      if ( p->second > maximumWeight ) {
        maximumWeight = p->second;
      }
      /* if the local node has forked everything, its local weight is 1.0. Such
       * a node has to be skipped
       */
      if ( p->second < minimumWeight && p->second > 1.0) {
        minimumWeight = p->second;
      }
    }
    assertion2( maximumWeight>=1.0, maximumWeight, minimumWeight );    assertion2( minimumWeight>=1.0, maximumWeight, minimumWeight );

    for ( std::map<int,double>::const_iterator p=_weightMap.begin(); p!=_weightMap.end(); p++ ) {
      if ( p->second >= (1.0-CritialPathThreshold) * maximumWeight ) {
        _criticalWorker.insert(p->first);
      }
    }
    _forksToConduct = minimumWeight < std::numeric_limits<double>::max() ?
      static_cast<int>(std::ceil(
        _maxForks*( 1.0-minimumWeight/maximumWeight )
      )) : 0;
    assertion4(_forksToConduct>=0, _forksToConduct, _maxForks, minimumWeight, maximumWeight);


    if (_forksToConduct==0 && maximumWeight <= (1.0+LocalMinimumThreshold)*minimumWeight) {
      _forksToConduct = peano::parallel::loadbalancing::ForkGreedy;

      for ( std::map<int,double>::const_iterator p=_weightMap.begin(); p!=_weightMap.end(); p++ ) {
        _criticalWorker.insert(p->first);
      }

      _maxForks = _maxForks > 2.0 ? _maxForks / 1.1 : 1.0;

      logDebug(
        "receivedStartCommand(int)",
        "identified local minimal, fork all " << _criticalWorker.size() <<
        " ranks with max forks factor " << _maxForks;
      );

    }
    else if (_forksToConduct==0 ) {
      _criticalWorker.clear();
    }
    else {
      if (_forksToConduct>peano::parallel::loadbalancing::ForkGreedy) {
        _forksToConduct = peano::parallel::loadbalancing::ForkGreedy;
      }
    }

    logInfo(
      "receivedStartCommand(int)",
      _forksToConduct << " forks should be done next on " << _criticalWorker.size() <<
      " worker(s) given the master fork command " << peano::parallel::loadbalancing::convertLoadBalancingFlagToString(commandFromMaster) <<
      ". Number of weight entries (workers+1)=" << _weightMap.size() <<
      ". Fork has failed before and vetos forks=" << _forkHasFailed
    );
  }

  _weightMap[tarch::parallel::Node::getInstance().getRank()] = 1.0;

  logTraceOutWith1Argument("receivedStartCommand(LoadBalancingFlag)", commandFromMaster);
}


int mpibalancing::StaticBalancing::getCommandForWorker( int workerRank, bool forkIsAllowed, bool joinIsAllowed ) {
  logTraceInWith4Arguments( "getCommandForWorker(int,bool)", workerRank, forkIsAllowed, joinIsAllowed, _joinsAllowed );
  
  int result = peano::parallel::loadbalancing::Continue;
  if ( tarch::parallel::Node::getInstance().isGlobalMaster() && _weightMap.size()==1 ) {
    result = peano::parallel::loadbalancing::ForkAllChildrenAndBecomeAdministrativeRank;
  }
  else if ( tarch::parallel::Node::getInstance().isGlobalMaster() ) {
    result = peano::parallel::loadbalancing::ForkOnce;
  }
  else if ( _makeChildrenAdministrativeRanks ) {
    result = peano::parallel::loadbalancing::ForkAllChildrenAndBecomeAdministrativeRank;
  }
  else {
    if (_joinsAllowed && _workerCouldNotEraseDueToDecomposition[workerRank] && joinIsAllowed) {
      _forkHasFailed = false;
      result         = peano::parallel::loadbalancing::Join;
      logInfo(
        "forkFailed()",
        "reset fork-has-failed flag as child command is " << peano::parallel::loadbalancing::convertLoadBalancingFlagToString(result)
      );
    }
    if (_joinsAllowed && _workerCouldNotEraseDueToDecomposition[workerRank] && !joinIsAllowed) {
      _forkHasFailed = false;
      result         = peano::parallel::loadbalancing::ContinueButTryToJoinWorkers;
      logInfo(
        "forkFailed()",
        "reset fork-has-failed flag as child command is " << peano::parallel::loadbalancing::convertLoadBalancingFlagToString(result)
      );
    }
    if (
      _criticalWorker.count(workerRank)>0 &&
      forkIsAllowed &&
      !_forkHasFailed &&
      _forksToConduct > 0
    ) {
      result         = _forksToConduct;
    }
  }

  logTraceOutWith1Argument( "getCommandForWorker(int,bool)", result );
  return result;
}


void mpibalancing::StaticBalancing::receivedTerminateCommand(
  int     workerRank,
  double  workerNumberOfInnerVertices,
  double  workerNumberOfBoundaryVertices,
  double  workerNumberOfOuterVertices,
  double  workerNumberOfInnerCells,
  double  workerNumberOfOuterCells,
  int     workerMaxLevel,
  double  workerLocalWorkload,
  double  workerTotalWorkload,
  double  workerMaxWorkload,
  double  workerMinWorkload,
  int     currentLevel,
  double  parentCellLocalWorkload,
  const tarch::la::Vector<DIMENSIONS,double>& boundingBoxOffset,
  const tarch::la::Vector<DIMENSIONS,double>& boundingBoxSize,
  bool    workerCouldNotEraseDueToDecomposition
) {
  _workerCouldNotEraseDueToDecomposition[workerRank] = workerCouldNotEraseDueToDecomposition;
  _weightMap[workerRank]                             = workerMaxWorkload > 0.0 ? workerMaxWorkload : 1.0;

  if (parentCellLocalWorkload>_weightMap[tarch::parallel::Node::getInstance().getRank()]) {
    _weightMap[tarch::parallel::Node::getInstance().getRank()] = parentCellLocalWorkload;
  }

  if (currentLevel <= _finestAdministrativeLevel) {
    _makeChildrenAdministrativeRanks = true;
  }
}


void mpibalancing::StaticBalancing::plotStatistics() {
}


peano::parallel::loadbalancing::OracleForOnePhase* mpibalancing::StaticBalancing::createNewOracle(int adapterNumber) const {
  return new StaticBalancing(_joinsAllowed);
}


void mpibalancing::StaticBalancing::couldNotEraseDueToDecomposition() {
}


void mpibalancing::StaticBalancing::forkFailed() {
  logInfo(
    "forkFailed()",
    "oracle was informed that fork has failed. No further fork attempts"
  );
  _forkHasFailed = true;
}


int mpibalancing::StaticBalancing::getCoarsestRegularInnerAndOuterGridLevel() const {
  return 3;
}
