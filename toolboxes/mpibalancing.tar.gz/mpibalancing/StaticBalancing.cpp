#include "mpibalancing/StaticBalancing.h"

#include "tarch/Assertions.h"
#include "tarch/la/ScalarOperations.h"
#include "tarch/parallel/Node.h"
#include "tarch/parallel/NodePool.h"
#include "peano/parallel/loadbalancing/Oracle.h"


tarch::logging::Log mpibalancing::StaticBalancing::_log( "mpibalancing::StaticBalancing" );


bool mpibalancing::StaticBalancing::_forkHasFailed = false;


mpibalancing::StaticBalancing::StaticBalancing(bool joinsAllowed):
  _joinsAllowed(joinsAllowed),
  _criticalWorker(-1),
  _forksToConduct(0) {
  _weightMap.insert( std::pair<int,double>(tarch::parallel::Node::getInstance().getRank(), 1.0) );

  _workerCouldNotEraseDueToDecomposition.insert( std::pair<int,bool>(tarch::parallel::Node::getInstance().getRank(), false) );
}


mpibalancing::StaticBalancing::~StaticBalancing() {
}


void mpibalancing::StaticBalancing::receivedStartCommand(const int commandFromMaster ) {
  logTraceInWith1Argument("receivedStartCommand(LoadBalancingFlag)", peano::parallel::loadbalancing::convertLoadBalancingFlagToString(commandFromMaster));

  // @todo es gibt keinen Grund, das persistent zu halten
  _commandFromMaster = commandFromMaster;

  if (
    commandFromMaster>=peano::parallel::loadbalancing::ForkOnce
//    ||
//    commandFromMaster==peano::parallel::loadbalancing::Continue
  ) {
    double criticalWeight = std::numeric_limits<double>::min();
    double minimumWeight  = std::numeric_limits<double>::max();
    for ( std::map<int,double>::const_iterator p=_weightMap.begin(); p!=_weightMap.end(); p++ ) {
      if ( p->second > criticalWeight ) {
        criticalWeight  = p->second;
        _criticalWorker = p->first;
      }
      // if the local node has forked everything, its local weight is 1.0 and this should not be
      if ( p->second < minimumWeight && p->second > 1.0) {
        minimumWeight = p->second;
      }
    }
    assertion2( criticalWeight>=1.0, criticalWeight, minimumWeight );
    assertion2( minimumWeight>=1.0, criticalWeight, minimumWeight );
//    assertion2( minimumWeight<=criticalWeight, criticalWeight, minimumWeight );
//
//    if ( _commandFromMaster>=peano::parallel::loadbalancing::ForkOnce && _criticalWorker!=tarch::parallel::Node::getInstance().getRank() ) {
//      // @todo Debug
//      logInfo( "receivedStartCommand(int)", "reset fork command as there is a critical worker with rank " << _criticalWorker );
//      _commandFromMaster = peano::parallel::loadbalancing::Continue;
//    }

    _forksToConduct = static_cast<int>(std::ceil(criticalWeight / minimumWeight));
    assertion(_forksToConduct>=0);

    if (_forksToConduct>1) {
      _forksToConduct--;
    }
    if (_forksToConduct>THREE_POWER_D-1) {
      _forksToConduct = THREE_POWER_D-1;
    }

    logDebug(
      "receivedStartCommand(int)",
      _forksToConduct << " forks should be done next on worker " << _criticalWorker <<
      " with local fork command " << peano::parallel::loadbalancing::convertLoadBalancingFlagToString(_commandFromMaster) <<
      ". Number of weight entries (workers+1)=" << _weightMap.size()
    );
  }
  else {
    _criticalWorker = -1;
  }


  _weightMap[tarch::parallel::Node::getInstance().getRank()] = 1.0;

  logTraceOutWith1Argument("receivedStartCommand(LoadBalancingFlag)", commandFromMaster);
}


int mpibalancing::StaticBalancing::getCommandForWorker( int workerRank, bool forkIsAllowed, bool joinIsAllowed ) {
  logTraceInWith4Arguments( "getCommandForWorker(int,bool)", workerRank, forkIsAllowed, joinIsAllowed, _joinsAllowed );
  
  int result = peano::parallel::loadbalancing::Continue;
  // very first time
  if ( tarch::parallel::Node::getInstance().isGlobalMaster() && _weightMap.size()==1 ) {
//    result = peano::parallel::loadbalancing::ForkGreedy;
    result = peano::parallel::loadbalancing::ForkAllChildrenAndBecomeAdministrativeRank;
  }
  else if ( tarch::parallel::Node::getInstance().isGlobalMaster() ) {
//    logInfo(
//      "getCommandForWorker(int,bool,bool)",
//      "weight for only worker is " << _weightMap[workerRank]
//    );
    result = peano::parallel::loadbalancing::ForkOnce;
//    result = peano::parallel::loadbalancing::Continue;
  }
  else {
    if (_joinsAllowed && _workerCouldNotEraseDueToDecomposition[workerRank] && joinIsAllowed) {
      _forkHasFailed = false;
      result         = peano::parallel::loadbalancing::Join;
    }
    if (_joinsAllowed && _workerCouldNotEraseDueToDecomposition[workerRank] && !joinIsAllowed) {
      _forkHasFailed = false;
      result         = peano::parallel::loadbalancing::ContinueButTryToJoinWorkers;
    }
    if (_criticalWorker==workerRank && forkIsAllowed && !_forkHasFailed && _forksToConduct > 0) {
      result         = _forksToConduct;
    }
  }

  logTraceOutWith1Argument( "getCommandForWorker(int,bool)", result );
  return result;
}


void mpibalancing::StaticBalancing::receivedTerminateCommand(
  int     workerRank,
  double  waitedTime,
  double  workerNumberOfInnerVertices,
  double  workerNumberOfBoundaryVertices,
  double  workerNumberOfOuterVertices,
  double  workerNumberOfInnerCells,
  double  workerNumberOfOuterCells,
  int     workerMaxLevel,
  double  workerLocalWorkload,
  double  workerTotalWorkload,
  int     currentLevel,
  double  parentCellLocalWorkload,
  double  parentCellTotalWorkload,
  const tarch::la::Vector<DIMENSIONS,double>& boundingBoxOffset,
  const tarch::la::Vector<DIMENSIONS,double>& boundingBoxSize,
  bool    workerCouldNotEraseDueToDecomposition
) {
  _workerCouldNotEraseDueToDecomposition[workerRank] = workerCouldNotEraseDueToDecomposition;
  _weightMap[workerRank]                             = workerLocalWorkload > 0.0 ? workerLocalWorkload : 1.0;

  if (parentCellLocalWorkload>_weightMap[tarch::parallel::Node::getInstance().getRank()]) {
    _weightMap[tarch::parallel::Node::getInstance().getRank()] = parentCellLocalWorkload;
  }
}


void mpibalancing::StaticBalancing::plotStatistics() {
}


peano::parallel::loadbalancing::OracleForOnePhase* mpibalancing::StaticBalancing::createNewOracle(int adapterNumber) const {
  return new StaticBalancing(_joinsAllowed);
}


void mpibalancing::StaticBalancing::couldNotEraseDueToDecomposition() {
}


void mpibalancing::StaticBalancing::forkFailed() {
  _forkHasFailed = true;
}


int mpibalancing::StaticBalancing::getCoarsestRegularInnerAndOuterGridLevel() const {
  return 3;
}
